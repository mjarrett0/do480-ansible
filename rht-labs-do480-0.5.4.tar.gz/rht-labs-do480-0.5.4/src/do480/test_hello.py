# See https://docs.pytest.org/en/stable
#   for more info on implementing tests.

def test_hello():
    print("Hello")
