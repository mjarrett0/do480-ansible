#
# Copyright 2021 Red Hat, Inc.
#
# NAME
#     observability-customize - DO480 Configure lab exercise script
#
# SYNOPSIS
#     observability-customize {start|finish}
#
#        start   - prepare the system for starting the lab
#        finish  - perform post-exercise cleanup steps
#
# CHANGELOG
#   * Tue Nov 9 2021 Alejandro Coma <acomabon@redhat.com>
#   - original code

"""
Lab script for DO480 Configure.
This module implements the start and finish functions for the
observability-customize guided exercise.
"""

import os
import subprocess
from .common import steps
from labs.common.userinterface import Console
from labs.grading import Default as GuidedExercise

from .common.constants import USER_NAME, IDM_SERVER, OCP4_API, OCP4_MNG_API

labname = 'observability-customize'
this_path = os.path.abspath(os.path.dirname(__file__))

class FeaturesUsers(GuidedExercise):
    """Activity class."""
    __LAB__ = labname

    def start(self):
        """
        Prepare systems for the lab exercise.
        """
        items = [
            steps.run_command(label="Verifying connectivity to OCP4 cluster", hosts=["workstation"], command="oc login", options="-u admin -p redhat " + OCP4_API, returns="0"),
            steps.run_command(label="Verifying RHACM Operator deployment", hosts=["workstation"], command="oc get csv -n open-cluster-management", options="", prints="Succeeded", failmsg="Install the RHACM Operator"),
            steps.run_command(label="Verifying RHACM MultiClusterHub deployment", hosts=["workstation"], command="oc", options="get multiclusterhub -n open-cluster-management", prints="Running", failmsg="Create the MultiClusterHub object"),
            steps.run_command(label="Verifying the availability of the local-cluster", hosts=["workstation"], command="oc", options="get managedclusters", prints="local-cluster", failmsg="Create the MultiClusterHub object"),
            steps.run_command(label="Verifying the availability of the managed-cluster", hosts=["workstation"], command="oc", options="get managedclusters", prints="managed-cluster", failmsg="Import the managed-cluster into RHACM"),
            steps.run_command(label="Verifying that the observability service is enabled", hosts=["workstation"], command="oc", options="get mco observability", returns="0", failmsg="The observability service is not enabled. Please complete the preceding guided exercise before attempting this."),
            steps.run_command(label="Logging out", hosts=["workstation"], command="oc", options="logout", returns="0")
        ]
        Console(items).run_items(action="Starting")

    def finish(self):
        """
        Perform any post-lab cleanup tasks.
        """
        get_obs = subprocess.run('/usr/bin/oc get mco observability', shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if get_obs.returncode == 0:
            items = [
                steps.run_command(label="Verifying connectivity to OCP4 cluster", hosts=["workstation"], command="oc login", options="-u admin -p redhat " + OCP4_API, returns="0"),
                steps.run_command(label="Removing the observability service", hosts=["workstation"], command="oc", options="delete mco observability", returns="0"),
                steps.run_command(label="Removing the open-cluster-management-observability namespace", hosts=["workstation"], command="oc", options="delete namespace open-cluster-management-observability", returns="0"),
                steps.run_command(label="Logging out", hosts=["workstation"], command="oc", options="logout", returns="0")
            ]
            Console(items).run_items(action="Finishing")
        else:
            items = [
                steps.run_command(label="Verifying connectivity to OCP4 cluster", hosts=["workstation"], command="oc login", options="-u admin -p redhat " + OCP4_API, returns="0"),
                steps.run_command(label="Logging out", hosts=["workstation"], command="oc", options="logout", returns="0")
            ]
            Console(items).run_items(action="Finishing")
