from setuptools import setup
import src.do480.version as ver

setup(
    include_package_data=True,
    version=ver.__version__
)
