#
# Copyright 2021 Red Hat, Inc.
#
# NAME
#     multicluster-acm - DO480 Configure lab exercise script
#
# SYNOPSIS
#     multicluster-acm {start|finish}
#
#        start   - prepare the system for starting the lab
#        finish  - perform post-exercise cleanup steps
#
# CHANGELOG
#   * Tue Nov 25 2021 Alejandro Coma <acomabon@redhat.com>
#   - original code

"""
Lab script for DO480 Configure.
This module implements the start and finish functions for the
multicluster-acm guided exercise.
"""

import os
import subprocess
from .common import steps
from labs.common.userinterface import Console
from labs.grading import Default as GuidedExercise

from .common.constants import USER_NAME, IDM_SERVER, OCP4_API, OCP4_MNG_API

labname = 'multicluster-acm'
this_path = os.path.abspath(os.path.dirname(__file__))
subprocess.run('/usr/bin/oc login -u admin -p redhat https://api.ocp4.example.com:6443', shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
csv = subprocess.check_output('/usr/bin/oc get sub -n open-cluster-management -o json | jq -r .items[0].status.installedCSV', shell=True, stderr=subprocess.DEVNULL)
csv_str = csv.decode(encoding='utf-8')

class MultiClusterACM(GuidedExercise):
    """Activity class."""
    __LAB__ = labname

    def start(self):
        """
        Prepare systems for the lab exercise.
        """
        items = [
            steps.run_command(label="Verifying connectivity to OCP4 cluster", hosts=["workstation"], command="oc login", options="-u admin -p redhat " + OCP4_API, returns="0"),
            steps.run_command(label="Verifying that the RHACM Operator subscription not present", hosts=["workstation"], command="oc get sub acm-operator-subscription -n open-cluster-management", options="", returns="1", failmsg="RHACM operator subscription detected. Run the command 'lab finish multicluster-acm' to remove it automatically."),
            steps.run_command(label="Verifying that the RHACM Operator is not installed", hosts=["workstation"], command="oc get csv " + str(csv_str) + " -n open-cluster-management", options="", returns="1", failmsg="RHACM operator detected. Run the command 'lab finish multicluster-acm' to remove it automatically."),
            steps.run_command(label="Verifying that the RHACM MultiClusterHub object is not present", hosts=["workstation"], command="oc", options="get multiclusterhub multiclusterhub -n open-cluster-management", returns="1", failmsg="MultiClusterHub detected. Run the command 'lab finish multicluster-acm' to remove it automatically."),
            steps.run_command(label="Logging out", hosts=["workstation"], command="oc", options="logout", returns="0")
        ]
        Console(items).run_items(action="Starting")

    def finish(self):
        items = [
            steps.run_command(label="Verifying connectivity to OCP4 cluster", hosts=["workstation"], command="oc login", options="-u admin -p redhat " + OCP4_API, returns="0"),
            steps.run_command(label="Running Ansible Playbook to remove RHACM. This command takes a while. Do not interrupt the execution.", hosts=["workstation"], command="ansible-playbook", options=" " + this_path + "/ansible/common/acm_remove.yaml -i " + this_path + "/ansible/common/inventory", returns="0"),
            steps.run_command(label="Logging out", hosts=["workstation"], command="oc", options="logout", returns="0")
        ]
        Console(items).run_items(action="Finishing")
