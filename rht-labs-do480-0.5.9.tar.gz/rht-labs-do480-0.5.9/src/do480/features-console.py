#
# Copyright 2021 Red Hat, Inc.
#
# NAME
#     features-console - DO480 Configure lab exercise script
#
# SYNOPSIS
#     features-console {start|finish}
#
#        start   - prepare the system for starting the lab
#        finish  - perform post-exercise cleanup steps
#
# CHANGELOG
#   * Tue Nov 5 2021 Rafa Ruiz
#   - original code

"""
Lab script for DO480 Configure.
This module implements the start and finish functions for the
features-console guided exercise.
"""

import os
from .common import steps
from labs.common.userinterface import Console
from labs.grading import Default as GuidedExercise

from .common.constants import USER_NAME, IDM_SERVER, OCP4_API, OCP4_MNG_API

labname = 'features-console'
this_path = os.path.abspath(os.path.dirname(__file__))

class FeaturesConsole(GuidedExercise):
    """Activity class."""
    __LAB__ = labname

    def start(self):
        """
        Prepare systems for the lab exercise.
        """
        items = [
            steps.run_command(label="Changing resolution for correct visualization of RHACM console", hosts=["workstation"], command="xrandr", options="--output Virtual-1 --mode 1920x1080", returns="0"),
            steps.run_command(label="Verifying connectivity to OCP4 managed cluster", hosts=["workstation"], command="oc login", options="-u admin -p redhat " + OCP4_MNG_API, returns="0"),
            steps.run_command(label="Verifying connectivity to OCP4 cluster", hosts=["workstation"], command="oc login", options="-u admin -p redhat " + OCP4_API, returns="0"),
            steps.run_command(label="Verifying RHACM Operator deployment", hosts=["workstation"], command="oc get csv -n open-cluster-management", options="", prints="Succeeded", failmsg="Install the RHACM Operator"),
            steps.run_command(label="Verifying RHACM MultiClusterHub deployment", hosts=["workstation"], command="oc", options="get multiclusterhub -n open-cluster-management", prints="Running", failmsg="Create the MultiClusterHub object"),
            steps.run_command(label="Verifying the availability of the local-cluster", hosts=["workstation"], command="oc", options="get managedclusters", prints="local-cluster", failmsg="Create the MultiClusterHub object"),
            steps.run_command(label="Verifying the availability of the managed-cluster", hosts=["workstation"], command="oc", options="get managedclusters", prints="managed-cluster", failmsg="Import the managed-cluster into RHACM"),
            steps.run_command(label="Creating all namespaces and deployments", hosts=["workstation"], command=this_path + "/files/features-console/create_all_persistence.sh", options="", returns="0"),
            steps.run_command(label="Logging out", hosts=["workstation"], command="oc", options="logout", returns="0")
        ]
        Console(items).run_items(action="Starting")

    def finish(self):
        """
        Perform any post-lab cleanup tasks.
        """
        items = [
            steps.run_command(label="Verifying connectivity to OCP4 cluster", hosts=["workstation"], command="oc login", options="-u admin -p redhat " + OCP4_API, returns="0"),
            steps.run_command(label="Deleting all namespaces and deployments", hosts=["workstation"], command=this_path + "/files/features-console/delete_all_persistence.sh", options="", returns="0"),
            steps.run_command(label="Reverting resolution to the initial one", hosts=["workstation"], command="xrandr", options="--output Virtual-1 --mode 1024x768", returns="0")
         
        ]
        Console(items).run_items(action="Finishing")
